def analyze(payload):
    side=payload.get("side","WAIT").upper()
    trend=payload.get("trend","RANGE").upper()
    zone=payload.get("zone","NONE").upper()
    po2=bool(payload.get("po2"))
    sweep=bool(payload.get("liquidity_sweep"))
    confirm=payload.get("confirmation","NONE").upper()
    false_breakout=bool(payload.get("false_breakout"))

    score=0
    reasons=[]

    if side=="BUY":
        if trend=="UP": score+=25; reasons.append("Trend aligned bullish")
        if zone in {"VS","RBS","SRR"}: score+=20; reasons.append("Bullish SNRZ zone")
        if po2: score+=20; reasons.append("PO2 present")
        if sweep: score+=15; reasons.append("Liquidity sweep")
        if confirm in {"BULLISH ENGULFING","BULLISH PIN"}: score+=20; reasons.append("Bullish confirmation")
    elif side=="SELL":
        if trend=="DOWN": score+=25; reasons.append("Trend aligned bearish")
        if zone in {"VR","SBR","RSS"}: score+=20; reasons.append("Bearish SNRZ zone")
        if po2: score+=20; reasons.append("PO2 present")
        if sweep: score+=15; reasons.append("Liquidity sweep")
        if confirm in {"BEARISH ENGULFING","BEARISH PIN"}: score+=20; reasons.append("Bearish confirmation")

    if false_breakout:
        score=max(0,score-30)
        reasons.append("False-breakout warning")

    decision = side if score>=70 and not false_breakout else "NO TRADE"
    return {"decision":decision,"score":min(score,100),"reasons":reasons}
