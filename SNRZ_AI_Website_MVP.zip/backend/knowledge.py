SNRZ_KNOWLEDGE = [
{"topic":"Core terminology","text":"SNRZ terminology includes S=Support, R=Resistance, SBR=Support Breakout to Resistance, RBS=Resistance Breakout to Support, V.S=Valid Support, V.R=Valid Resistance, I-VS=Inversion Valid Support, I-VR=Inversion Valid Resistance, PO2=Power Of Second Touch, SRR=Support Breakout 2 Resistance, RSS=Resistance Breakout 2 Support, and GAP Strategy."},
{"topic":"Timeframes","text":"The supplied SNRZ material uses higher timeframes for analysis and lower timeframes for confirmation/monitoring. The material shows Weekly, Daily, H4, H1 and M15 for analysis, with H4, H1, M30, M15 and M5 for confirmation; monitoring also includes M15, M5 and M1."},
{"topic":"Liquidity Sweep","text":"The supplied diagrams describe a liquidity sweep as a wick/shadow taking liquidity beyond a support or resistance area and returning; the examples label buy/sell signals around the sweep."},
{"topic":"Liquidity Run","text":"The supplied diagrams distinguish a confirmed breakout/liquidity run from a sweep and show continuation after the break."},
{"topic":"V.S / V.R","text":"The source diagrams describe valid support and valid resistance using first movement, second movement and a zone. The implementation should require repeated interaction with a zone before treating it as a stronger candidate."},
{"topic":"RBS / SBR","text":"RBS is resistance becoming support after a confirmed break. SBR is support becoming resistance after a confirmed break."},
{"topic":"SRR / RSS","text":"SRR is support broken to resistance or more; RSS is resistance broken to support or more. The source includes practical chart examples."},
{"topic":"PO2","text":"PO2 means Power Of Second Touch. The source shows a first touch and a second touch at a zone, with the second interaction used as the setup area."},
{"topic":"False Breakout","text":"The source contains false-breakout areas and examples. A deterministic implementation should distinguish a wick/sweep that closes back inside from a confirmed close outside the zone."},
{"topic":"Confirmation","text":"The supplied material includes bullish/bearish engulfing examples and confirmation timeframes. The website should show the confirmation evidence rather than treating a score as certainty."},
{"topic":"Risk","text":"The website should calculate and display entry, stop loss and targets, then apply a risk filter before any trade action. Live execution should remain disabled until backtesting and demo/forward testing are complete."}
]

def search(query):
    q=query.lower()
    words=[w for w in q.split() if len(w)>2]
    scored=[]
    for item in SNRZ_KNOWLEDGE:
        hay=(item["topic"]+" "+item["text"]).lower()
        score=sum(1 for w in words if w in hay)
        if score:
            scored.append((score,item))
    return [x[1] for x in sorted(scored,key=lambda x:x[0],reverse=True)[:5]]
