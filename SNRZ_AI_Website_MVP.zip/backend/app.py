from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from .knowledge import search
from .rules import analyze

app=FastAPI(title="SNRZ AI Website")

class Chat(BaseModel):
    message:str

class Analysis(BaseModel):
    side:str="WAIT"
    trend:str="RANGE"
    zone:str="NONE"
    po2:bool=False
    liquidity_sweep:bool=False
    confirmation:str="NONE"
    false_breakout:bool=False

@app.get("/",response_class=HTMLResponse)
def home():
    return Path("frontend/index.html").read_text(encoding="utf-8")

@app.post("/api/chat")
def chat(body:Chat):
    hits=search(body.message)
    if not hits:
        return {"answer":"ئەم بابەتە هێشتا لە SNRZ knowledge base ـدا بە ڕوونی نەدۆزرایەوە.","sources":[]}
    answer="\\n\\n".join([f"{h['topic']}: {h['text']}" for h in hits])
    return {"answer":answer,"sources":[h["topic"] for h in hits]}

@app.post("/api/analyze")
def do_analyze(body:Analysis):
    return analyze(body.model_dump())

@app.get("/api/health")
def health():
    return {"status":"ok","mode":"PAPER"}
