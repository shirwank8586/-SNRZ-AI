# SNRZ AI Website — MVP

A web-based SNRZ learning assistant and XAUUSD analysis dashboard.

## What this MVP does
- SNRZ knowledge base from the supplied material
- Kurdish/Sorani-friendly chat interface
- SNRZ rule checklist
- XAUUSD signal-analysis form
- BUY / SELL / NO TRADE decision framework
- SNRZ score
- Entry / SL / TP1 / TP2 fields
- Paper mode by default

## Architecture
Browser -> FastAPI -> SNRZ knowledge/rule engine -> optional AI model -> result

## Important
The supplied SNRZ PDFs contain many diagrams and discretionary chart examples. This MVP converts the
documented concepts into structured rules, but it is NOT a claim that every visual judgment has been
automated.

For real AI training, the next stage is to label hundreds/thousands of XAUUSD chart examples:
V.S, V.R, PO2, RBS, SBR, SRR, RSS, liquidity sweep, liquidity run, fresh, inversion, false breakout,
BUY, SELL, NO TRADE, entry, SL, TP1 and TP2.

## Run
Python 3.11+

```bash
pip install -r requirements.txt
uvicorn backend.app:app --reload
```

Open http://127.0.0.1:8000

Set `AI_API_KEY` only when connecting an external AI model. Keep trading in PAPER mode while testing.
